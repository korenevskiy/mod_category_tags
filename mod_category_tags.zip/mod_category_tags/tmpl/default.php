<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_tags_popular
 *
 * @copyright   (C) 2013 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Component\Tags\Site\Helper\RouteHelper;

?>
<div class="mod-tagspopular tagspopular">
<?php if (!count($list)) : ?>
	<div class="alert alert-info">
		<span class="icon-info-circle" aria-hidden="true"></span><span class="visually-hidden"><?php echo Text::_('INFO'); ?></span>
		<?php echo Text::_('MOD_CATEGORY_TAGS_NO_ITEMS_FOUND'); ?>
	</div>
<?php else : ?>
	<ul>
	<?php foreach ($list as $item) : ?>
	<li>
		<a href="<?php
		$cat_id = $item->cat_id ? "id=$item->cat_id" : '';
echo Route::_("index.php?option=com_content&view=category&layout=blog&$cat_id&filter_tag=$item->tag_id");
//index.php?option=com_content&view=category&layout=blog&id=8
//index.php?option=com_content&view=category&layout=blog&id=8&filter_tag[0]=13						Аренда
//index.php?option=com_content&view=category&layout=blog&id=8&filter_tag[0]=13&filter_tag[1]=4		Аренда, Электрика и освещение
//toPrint(RouteHelper::getTagRoute($item->tag_id . ':' . $item->alias),'Link',0,'message');
		
		
		//echo Route::_(RouteHelper::getCategoryRoute($item->cat_id, $item->language)); //$item->cat_title
		
		
//		echo Route::_(RouteHelper::getTagRoute($item->tag_id . ':' . $item->alias)); ?>">
			<?php echo htmlspecialchars($item->title, ENT_COMPAT, 'UTF-8'); ?> 
		
		</a>
		<?php if ($display_count) : ?>
			<span class="tag-count badge bg-info"><?php echo $item->count; ?></span>
		<?php endif; ?>
		<?php if ($categories_titles) : ?>
			<span class="tag-category badge bg-info"><?php echo $item->cat_title; ?></span>
		<?php endif; ?>
	</li>
	<?php endforeach; ?>
	</ul>
<?php endif; ?>
</div>
